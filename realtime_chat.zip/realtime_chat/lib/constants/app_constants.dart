class AppConstants {
  static const appTitle = "Euro Food Live Support";
  static const loginTitle = "Login";
  static const homeTitle = "Home";
  static const settingsTitle = "Settings";
  static const fullPhotoTitle = "Full Photo";
}
