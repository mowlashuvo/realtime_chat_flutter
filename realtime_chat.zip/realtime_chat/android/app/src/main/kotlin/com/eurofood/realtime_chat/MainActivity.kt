package com.eurofood.realtime_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
